<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TAMBAH PEMINJAMAN</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <form action="{{ route('peminjamans.store') }}" method="POST" enctype="multipart/form-data">
                        
                            @csrf

                            <div class="form-group">
                                <label class="font-weight-bold">NAMA</label>
                                <select class="form-control @error('id_siswa') is-invalid @enderror" name="id_siswa" size="1">
                                    <option value="" selected disabled>~ Pilih Nama Siswa ~</option>
                                    {{-- Looping untuk menampilkan nama-nama siswa --}}
                                    @foreach($siswas as $siswa)
                                        <option value="{{ $siswa->id }}">{{ $siswa->nama }}</option>
                                    @endforeach
                                </select>

                                <!-- error message untuk id_siswa -->
                                @error('id_siswa')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">BARANG</label>
                                <select class="form-control @error('id_barang') is-invalid @enderror" name="id_barang" id="id_barang" size="1">
                                    <option value="" selected disabled>~ Pilih Nama Barang ~</option>
                                    @foreach($barangs as $barang)
                                        <option value="{{ $barang->id }}" data-image="{{ asset('storage/barangs/' . $barang->image) }}" data-kode="{{ $barang->kode_barang }}">
                                            {{ $barang->nama_barang }} - {{ $barang->kode_barang }}
                                        </option>
                                    @endforeach
                                </select>

                                <!-- error message untuk id_barang -->
                                @error('id_barang')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">GAMBAR</label>
                                <img id="gambar_barang" src="" alt="Gambar Barang" style="width: 250px;">
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">TANGGAL PINJAM</label>
                                <input type="datetime-local" class="form-control @error('tgl_pinjam') is-invalid @enderror" name="tgl_pinjam" value="{{ old('tgl_pinjam') }}">
                            
                                <!-- error message untuk tgl_bayar -->
                                @error('tgl_pinjam')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            
                            <div class="form-group">
                                <label class="font-weight-bold">TANGGAL KEMBALI</label>
                                <input type="datetime-local" class="form-control @error('tgl_kembali') is-invalid @enderror" name="tgl_kembali" value="{{ old('tgl_kembali') }}">
                            
                                <!-- error message untuk tgl_bayar -->
                                @error('tgl_kembali')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">KONDISI PENGEMBALIAN</label>
                                <select class="form-control @error('kondisi') is-invalid @enderror" name="kondisi" size="1">
                                    <option value="" selected disabled>~ Pilih Kondisi Barang ~</option>
                                    <option value="BAIK" {{ (old('kondisi') == 'BAIK') ? 'selected' : '' }}>BAIK</option>
                                    <option value="KURANG BAIK" {{ (old('kondisi') == 'KURANG BAIK') ? 'selected' : '' }}>KURANG BAIK</option>
                                    <option value="RUSAK" {{ (old('kondisi') == 'RUSAK') ? 'selected' : '' }}>RUSAK</option>
                                </select>

                                <!-- error message untuk nama -->
                                @error('kondisi')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        // Ketika pilihan barang berubah
        $('#id_barang').change(function () {
            var selectedImage = $(this).find(':selected').data('image');
            // Ganti src gambar
            $('#gambar_barang').attr('src', selectedImage);
        });
    });
</script>
</body>
</html>